
package com.example.scicalc;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class ExpressionEvaluator {

    public static double evaluate(String expression, boolean degreeMode) {
        List<String> tokens = tokenize(expression);
        List<String> rpn = infixToRPN(tokens);
        return evalRPN(rpn, degreeMode);
    }


    private static List<String> tokenize(String expr) {
        String s = expr.replaceAll("\\s+", "");
        List<String> tokens = new ArrayList<>();
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (Character.isDigit(c) || c == '.') {
                StringBuilder sb = new StringBuilder();
                while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) {
                    sb.append(s.charAt(i++));
                }
                tokens.add(sb.toString());
                continue;
            }
            if (Character.isLetter(c)) {
                StringBuilder sb = new StringBuilder();
                while (i < s.length() && Character.isLetter(s.charAt(i))) {
                    sb.append(s.charAt(i++));
                }
                tokens.add(sb.toString());
                continue;
            }
            if (c == '(' || c == ')' || c == ',' ) {
                tokens.add(String.valueOf(c)); i++; continue;
            }

            tokens.add(String.valueOf(c)); i++;
        }


        List<String> out = new ArrayList<>();
        for (int j = 0; j < tokens.size(); j++) {
            String t = tokens.get(j);
            if (t.equals("-")) {
                if (j == 0) out.add("u-");
                else {
                    String prev = tokens.get(j - 1);
                    if (prev.equals("(") || prev.equals("+") || prev.equals("-") || prev.equals("*") || prev.equals("/") || prev.equals("^") || prev.equals(",")) {
                        out.add("u-");
                    } else out.add(t);
                }
            } else out.add(t);
        }
        return out;
    }


    private static int prec(String op) {
        switch (op) {
            case "u-": return 5;
            case "fact": return 5;
            case "^": return 4;
            case "*": case "/": case "%": return 3;
            case "+": case "-": return 2;
            default: return 0;
        }
    }

    private static boolean isLeftAssoc(String op) {
        if (op.equals("^")) return false;
        return true;
    }

    private static boolean isFunction(String token) {
        return token.equals("sin") || token.equals("cos") || token.equals("tan") ||
                token.equals("ln") || token.equals("log") || token.equals("sqrt") ||
                token.equals("fact");
    }

    private static boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") ||
                token.equals("/") || token.equals("^") || token.equals("%") ||
                token.equals("u-") || token.equals("fact");
    }


    private static List<String> infixToRPN(List<String> tokens) {
        List<String> output = new ArrayList<>();
        Stack<String> stack = new Stack<>();
        for (String token : tokens) {
            if (isNumber(token)) {
                output.add(token);
            } else if (isFunction(token)) {
                stack.push(token);
            } else if (token.equals(",")) {
                while (!stack.isEmpty() && !stack.peek().equals("(")) output.add(stack.pop());
            } else if (token.equals("(")) {
                stack.push(token);
            } else if (token.equals(")")) {
                while (!stack.isEmpty() && !stack.peek().equals("(")) output.add(stack.pop());
                if (stack.isEmpty()) throw new IllegalArgumentException("Mismatched parentheses");
                stack.pop();
                if (!stack.isEmpty() && isFunction(stack.peek())) output.add(stack.pop());
            } else if (isOperator(token)) {
                while (!stack.isEmpty() && isOperator(stack.peek())) {
                    String op2 = stack.peek();
                    int p1 = prec(token);
                    int p2 = prec(op2);
                    if ((isLeftAssoc(token) && p1 <= p2) || (!isLeftAssoc(token) && p1 < p2)) {
                        output.add(stack.pop());
                    } else break;
                }
                stack.push(token);
            } else {
                throw new IllegalArgumentException("Unknown token: " + token);
            }
        }
        while (!stack.isEmpty()) {
            String t = stack.pop();
            if (t.equals("(") || t.equals(")")) throw new IllegalArgumentException("Mismatched parentheses");
            output.add(t);
        }
        return output;
    }

    private static boolean isNumber(String token) {
        try {
            Double.parseDouble(token); return true;
        } catch (Exception e) { return false; }
    }


    private static double evalRPN(List<String> rpn, boolean degreeMode) {
        Stack<Double> st = new Stack<>();
        for (String token : rpn) {
            if (isNumber(token)) {
                st.push(Double.parseDouble(token));
            } else if (token.equals("u-")) {
                if (st.isEmpty()) throw new IllegalArgumentException("Invalid unary minus");
                st.push(-st.pop());
            } else if (token.equals("+")) {
                double b = st.pop(), a = st.pop(); st.push(a + b);
            } else if (token.equals("-")) {
                double b = st.pop(), a = st.pop(); st.push(a - b);
            } else if (token.equals("*")) {
                double b = st.pop(), a = st.pop(); st.push(a * b);
            } else if (token.equals("/")) {
                double b = st.pop(), a = st.pop();
                if (b == 0.0) throw new ArithmeticException("Division by zero");
                st.push(a / b);
            } else if (token.equals("%")) {
                double b = st.pop(), a = st.pop(); st.push(a % b);
            } else if (token.equals("^")) {
                double b = st.pop(), a = st.pop(); st.push(Math.pow(a, b));
            } else if (isFunction(token) || token.equals("fact")) {
                double a = st.pop();
                switch (token) {
                    case "sin":
                        if (degreeMode) a = Math.toRadians(a);
                        st.push(Math.sin(a));
                        break;
                    case "cos":
                        if (degreeMode) a = Math.toRadians(a);
                        st.push(Math.cos(a));
                        break;
                    case "tan":
                        if (degreeMode) a = Math.toRadians(a);
                        st.push(Math.tan(a));
                        break;
                    case "ln":
                        if (a <= 0) throw new ArithmeticException("ln domain");
                        st.push(Math.log(a));
                        break;
                    case "log":
                        if (a <= 0) throw new ArithmeticException("log domain");
                        st.push(Math.log10(a));
                        break;
                    case "sqrt":
                        if (a < 0) throw new ArithmeticException("sqrt of negative");
                        st.push(Math.sqrt(a));
                        break;
                    case "fact":
                        st.push(factorial(a));
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown function: " + token);
                }
            } else {
                throw new IllegalArgumentException("Unsupported token: " + token);
            }
        }
        if (st.size() != 1) throw new IllegalArgumentException("Invalid expression");
        return st.pop();
    }

    private static double factorial(double x) {
        if (x < 0) throw new ArithmeticException("Factorial of negative");
        long n = (long) x;
        if (n != x) throw new ArithmeticException("Factorial requires integer");
        if (n > 20) throw new ArithmeticException("Factorial too large");
        long res = 1;
        for (long i = 2; i <= n; i++) res *= i;
        return (double) res;
    }
}
