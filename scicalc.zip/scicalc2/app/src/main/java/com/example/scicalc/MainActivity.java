package com.example.scicalc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvDisplay;
    private boolean degreeMode = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // system picks layout-land automatically


        tvDisplay = findViewById(R.id.tvDisplay);


        int[] ids = new int[] {

                R.id.btn0_p, R.id.btn1_p, R.id.btn2_p, R.id.btn3_p, R.id.btn4_p,
                R.id.btn5_p, R.id.btn6_p, R.id.btn7_p, R.id.btn8_p, R.id.btn9_p,
                R.id.btnplus_p, R.id.btnminus_p, R.id.btnmul_p, R.id.btndiv_p,
                R.id.btnAC_p, R.id.btnplusminus_p, R.id.btnpercent_p, R.id.btndot_p, R.id.btnequal_p,


                R.id.btnSin, R.id.btnCos, R.id.btnTan, R.id.btnLn, R.id.btnLog,
                R.id.btnSqrt, R.id.btnPow, R.id.btnFact,


                R.id.toggleDeg
        };

        for (int id : ids) {
            View v = findViewById(id);
            if (v != null) v.setOnClickListener(this);
        }


        ToggleButton toggleDeg = findViewById(R.id.toggleDeg);
        if (toggleDeg != null) {
            toggleDeg.setOnCheckedChangeListener((buttonView, isChecked) -> degreeMode = isChecked);
        }
    }

    @Override
    public void onClick(View view) {
        if (tvDisplay == null) {
            Toast.makeText(this, "Display missing", Toast.LENGTH_SHORT).show();
            return;
        }

        int id = view.getId();

        try {

            if (id == R.id.btnAC_p) { tvDisplay.setText("0"); return; }


            if (id == R.id.btnequal_p) { evaluateAndShow(); return; }


            if (id == R.id.btndot_p) { appendDot(); return; }

            // Sign toggle
            if (id == R.id.btnplusminus_p) { toggleSign(); return; }

            // Percent
            if (id == R.id.btnpercent_p) { applyPercent(); return; }

            // Operators
            if (id == R.id.btnplus_p) { appendOperator("+"); return; }
            if (id == R.id.btnminus_p) { appendOperator("-"); return; }
            if (id == R.id.btnmul_p) { appendOperator("*"); return; }
            if (id == R.id.btndiv_p) { appendOperator("/"); return; }


            if (id == R.id.btn0_p) { appendDigit("0"); return; }
            if (id == R.id.btn1_p) { appendDigit("1"); return; }
            if (id == R.id.btn2_p) { appendDigit("2"); return; }
            if (id == R.id.btn3_p) { appendDigit("3"); return; }
            if (id == R.id.btn4_p) { appendDigit("4"); return; }
            if (id == R.id.btn5_p) { appendDigit("5"); return; }
            if (id == R.id.btn6_p) { appendDigit("6"); return; }
            if (id == R.id.btn7_p) { appendDigit("7"); return; }
            if (id == R.id.btn8_p) { appendDigit("8"); return; }
            if (id == R.id.btn9_p) { appendDigit("9"); return; }


            if (id == R.id.btnSin) { appendFunction("sin"); return; }
            if (id == R.id.btnCos) { appendFunction("cos"); return; }
            if (id == R.id.btnTan) { appendFunction("tan"); return; }
            if (id == R.id.btnLn) { appendFunction("ln"); return; }
            if (id == R.id.btnLog) { appendFunction("log"); return; }
            if (id == R.id.btnSqrt) { appendFunction("sqrt"); return; }
            if (id == R.id.btnPow) { appendOperator("^"); return; }
            if (id == R.id.btnFact) { appendFunction("fact"); return; }

        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            tvDisplay.setText("Error");
        }
    }



    private void appendDigit(String d) {
        String cur = tvDisplay.getText().toString();
        if (cur.equals("0") || cur.equals("Error")) tvDisplay.setText(d);
        else tvDisplay.append(d);
    }

    private void appendOperator(String op) {
        String cur = tvDisplay.getText().toString();
        if (cur.isEmpty()) return;
        char last = cur.charAt(cur.length() - 1);
        if ("+-*/^".indexOf(last) >= 0) tvDisplay.setText(cur.substring(0, cur.length() - 1) + op);
        else tvDisplay.append(op);
    }

    private void appendDot() {
        String cur = tvDisplay.getText().toString();
        int i = cur.length() - 1;
        while (i >= 0 && (Character.isDigit(cur.charAt(i)) || cur.charAt(i) == '.')) i--;
        String lastToken = cur.substring(i + 1);
        if (!lastToken.contains(".")) tvDisplay.append(".");
    }

    private void toggleSign() {
        String cur = tvDisplay.getText().toString();
        if (cur.equals("0") || cur.equals("Error")) return;
        if (cur.startsWith("-")) tvDisplay.setText(cur.substring(1));
        else tvDisplay.setText("-" + cur);
    }

    private void applyPercent() {
        try {
            double val = ExpressionEvaluator.evaluate(tvDisplay.getText().toString(), degreeMode);
            val /= 100.0;
            tvDisplay.setText(formatResult(val));
        } catch (Exception e) {
            Toast.makeText(this, "Invalid percent", Toast.LENGTH_SHORT).show();
            tvDisplay.setText("Error");
        }
    }

    private void appendFunction(String name) {
        if (name.equals("fact")) tvDisplay.append("fact(");
        else tvDisplay.append(name + "(");
    }

    private void evaluateAndShow() {
        String expr = tvDisplay.getText().toString();
        try {
            double result = ExpressionEvaluator.evaluate(expr, degreeMode);
            tvDisplay.setText(formatResult(result));
        } catch (ArithmeticException ae) {
            Toast.makeText(this, "Math error: " + ae.getMessage(), Toast.LENGTH_SHORT).show();
            tvDisplay.setText("Error");
        } catch (Exception e) {
            Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
            tvDisplay.setText("Error");
        }
    }

    private String formatResult(double value) {
        if (Double.isNaN(value)) return "Error";
        if (Double.isInfinite(value)) return "Infinity";
        long asLong = (long) value;
        if (value == asLong) return String.valueOf(asLong);
        return String.format("%.8f", value).replaceAll("\\.?0+$", "");
    }
}
